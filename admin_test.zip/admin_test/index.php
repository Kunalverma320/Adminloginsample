<?php
// session_start();
// $user_role=$_SESSION['user_role'];
// echo $user_role;
?>


<!DOCTYPE html>
<html>

<head>
    <title>
        Create Sticky Header/Footer on a Web Page
        using HTML CSS and JavaScript
    </title>

    <style>
    body {
        margin: 0px;
        padding: 0px;
        box-sizing: border-box;
    }

    .header {
        position: sticky;
        top: 0;
        text-align: center;
        background-color: lightgray;
        padding: 20px;
    }

    .navigation ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .navigation li {
        display: inline;
        margin-right: 10px;
    }

    .navigation a {
        text-decoration: none;
        color: #333;
    }

    .footer {
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: lightgray;
        padding: 10px;
        text-align: center;
    }

    .content {
        margin-bottom: 100px;
    }
    </style>
</head>

<body>
    
<?php include("includes/header.php");  ?>

    <div class="content">
        <h2 style="text-align: center;" id="html">
            HTML
        </h2>



        <p>
            HTML stands for HyperText Markup Language.
            It is used to design the web pages. With
            the help of HTML, you can create a complete
            website structure. HTML is the combination
            of Hypertext and Markup language. Hypertext
            defines the link between the web pages and
            markup language defines the text document
            within the tag that define the structure
            of web pages.
        </p>


<?php include("includes/footer.php"); ?>
        <footer class="footer">
            <p>© 2023 GFG. All rights reserved.</p>
        </footer>
</body>

</html>