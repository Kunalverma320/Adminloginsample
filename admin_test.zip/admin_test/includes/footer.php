


<footer class="footer">
            <p>© 2023 GFG. All rights reserved.</p>
        </footer>