<?php   session_start() ?>

<header class="header">
        <h1>Sticky Header</h1>
        <nav class="navigation">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="html.php">Html</a></li>
                <?php if(isset($_SESSION['user_role'])){ ?>
                <li><a href="html.php">My Profile</a></li>
                <?php } ?>
                <?php if(!isset($_SESSION['user_role'])){ ?>

                <li><a href="login.php">Login</a></li>
                <?php } ?>
                <?php if(isset($_SESSION['user_role'])){ ?>
                <li><a href="logout.php">Logout</a></li>
                <?php } ?>
            </ul>
        </nav>
    </header>