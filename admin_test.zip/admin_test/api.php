<?php
include("config.php");

header('Content-Type: application/json');

$sql = "SELECT * FROM `users`"; 
$sql_check = mysqli_query($con, $sql);

if (!$sql_check) {

    $error_message = mysqli_error($con);
    $response = array(
        "success" => false,
        "message" => "Query failed: " . $error_message
    );
    echo json_encode($response);
} else {

    $rows = array();
    while ($row = mysqli_fetch_assoc($sql_check)) {
        $rows[] = $row;
    }
    echo json_encode($rows);
}
mysqli_close($con); 
